Table C3 — Test results index (updated)

| Page | Scanner run | File (reports/) | Issues | Status |
|---|---|---:|---:|---|
| / (build) | pa11y build scan | `pa11y-build-home.json` / `.html` | 6 | needs review (contrast issues)
| / (live) | pa11y live scan | `pa11y-live-home.json` / `.html` | 26 | action required (third-party injections, missing accessible names)
| /contact (build) | pa11y build scan | `pa11y-build-contact.json` / `.html` | 2 | minor (title/lang)
| /contact (live) | pa11y live scan | `pa11y-live-contact.json` / `.html` | 29 | action required (form labels, anchor text)
| /accessibility-statement (build) | pa11y build scan | `pa11y-build-accessibility-statement.json` / `.html` | 0 | passed

Notes:
- Counts come from `reports/pa11y-summary.json` (generated on 2025-09-26).
- "Live" scans reflect the public site (https://wiseglobalresearch.com) and include third-party widget issues (Google Translate) that are documented in `Documentation/third-party-mitigation.md`.

