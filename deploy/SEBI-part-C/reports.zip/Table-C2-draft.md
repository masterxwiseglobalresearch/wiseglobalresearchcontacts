Table C2 — Accessibility Remediation Mapping (final)

| Page | Issue (scanner) | Remediation | Fixed in commit |
|---|---:|---|---|
| / | Contrast failures for small-market percentage text (build: 6 issues, live: 9 issues) | Increased color contrast to WCAG AA compliant hex values (`#008932` / `#de3333`) and replaced utility color classes with inline style references in `src/pages/Index.js`. | main (2025-09-26)
| / | Button elements without accessible names (live) | Added aria-labels or screen-reader-only text for SVG-only buttons where appropriate (see `src/components/*` and follow-up PRs). Partial mitigation applied in Footer for third-party widgets. | main (2025-09-26)
| /contact | Form fields missing labels (live: 29 issues) | Ensure each input/textarea has an associated `<label for="...">` or `aria-label`/`aria-labelledby`. Added guidance and partial fixes; final markup changes scheduled. | main (2025-09-26)
| All pages | Third-party widget (Google Translate) injection produces form/iframe elements without accessible names | Implemented runtime sanitation in `src/components/Footer.js` to set `title`, `aria-hidden` and attempt `inert` on injected iframes/forms; documented the mitigation in `Documentation/third-party-mitigation.md`. For audit: these remain third-party-controlled and are documented as an exception with mitigation. | main (2025-09-26)

Notes:
- Counts for each report are in `reports/pa11y-summary.json` (generated 2025-09-26).
- Live-site counts reflect the public domain `https://wiseglobalresearch.com` and include third-party items that cannot be fully fixed in-app.

